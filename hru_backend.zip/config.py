DATABASE_URI = 'mysql://root:@localhost/hru'
SECRET_KEY = 'asdjasd02309jDs'